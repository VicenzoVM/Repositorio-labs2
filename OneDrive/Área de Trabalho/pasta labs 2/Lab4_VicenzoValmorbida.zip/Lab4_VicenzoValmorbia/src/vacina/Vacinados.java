package vacina;

import java.util.*;

public class Vacinados {
	private ArrayList<Paciente> vacinados;
	
	
	public Vacinados() {
		this.vacinados = new ArrayList <Paciente>();
	}


	public ArrayList<Paciente> getVacinados() {
		return vacinados;
	}


	public void setVacinados(ArrayList<Paciente> vacinados) {
		this.vacinados = vacinados;
	}
	
	

}
