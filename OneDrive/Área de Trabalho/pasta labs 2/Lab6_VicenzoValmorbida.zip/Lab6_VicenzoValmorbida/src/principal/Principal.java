package principal;


import ui.Ui;

public class Principal {
	public static void main(String[] args) {
		
		
		 
		
		
		
		//e.candidatoMaisJovem();
		//e.candidatoMaisVelho();
		//e.candidatoMaisVotado();
		//e.candidatoMenosVotado();
		//System.out.println(e.getCandidatos());
		//System.out.println(e.totalDeVotos());
		//e.porcentagemDeVotos();
		Ui ui = new Ui();
		ui.Userinterface();
	}
	

}
